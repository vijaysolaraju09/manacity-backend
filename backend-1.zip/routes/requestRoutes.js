const express = require("express");
const router = express.Router();
const Request = require("../models/Request");
const User = require("../models/User");
const auth = require("../middleware/authMiddleware");

// Send verification or business request
router.post("/", auth, async (req, res) => {
  const { type, message } = req.body;

  const existing = await Request.findOne({
    user: req.user._id,
    type,
    status: "pending",
  });
  if (existing) return res.status(400).json({ msg: "Already requested" });

  const request = new Request({ user: req.user._id, type, message });
  await request.save();
  res.json({ msg: "Request sent", request });
});

// Admin approves request
router.patch("/:id/approve", async (req, res) => {
  const request = await Request.findById(req.params.id).populate("user");
  if (!request) return res.status(404).json({ msg: "Not found" });

  request.status = "approved";
  await request.save();

  request.user.role = request.type;
  if (request.type === "verified") request.user.isVerified = true;
  await request.user.save();

  res.json({ msg: "Request approved", user: request.user });
});

module.exports = router;
