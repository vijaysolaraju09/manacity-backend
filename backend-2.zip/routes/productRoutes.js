const express = require("express");
const router = express.Router();
const Product = require("../models/Product");
const auth = require("../middleware/authMiddleware");

// Get all admin products
router.get("/admin", auth, async (req, res) => {
  const products = await Product.find({ addedByAdmin: true });
  res.json({ products });
});

// Get all products from a shop
router.get("/shop/:shopId", auth, async (req, res) => {
  const products = await Product.find({ owner: req.params.shopId });
  res.json({ products });
});

// Get product by ID
router.get("/:id", auth, async (req, res) => {
  const product = await Product.findById(req.params.id);
  res.json({ product });
});

module.exports = router;
