const router = require("express").Router();
const eventController = require("../controllers/eventController");
const auth = require("../middleware/auth");

router.get("/", eventController.getAllEvents);
router.post("/", auth, eventController.createEvent); // Only admin in future
router.post("/register/:id", auth, eventController.registerEvent);
router.get("/mine", auth, eventController.getMyEvents);

module.exports = router;
