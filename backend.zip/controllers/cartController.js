exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user.id }).populate({
      path: "items.productId",
      populate: { path: "shopId", select: "name location phone" }, // populating shop info
    });

    if (!cart) return res.status(404).json({ msg: "Cart not found" });

    // Group products by shop
    const grouped = {};

    cart.items.forEach((item) => {
      const product = item.productId;
      if (!product || !product.shopId) return;

      const shopId = product.shopId._id;
      const shopName = product.shopId.name;

      if (!grouped[shopId]) {
        grouped[shopId] = {
          shop: {
            _id: shopId,
            name: shopName,
            location: product.shopId.location,
            phone: product.shopId.phone,
          },
          products: [],
        };
      }

      grouped[shopId].products.push({
        _id: product._id,
        name: product.name,
        price: product.price,
        image: product.image,
        description: product.description,
        quantity: item.quantity,
      });
    });

    res.json({ cartByShop: Object.values(grouped) });
  } catch (err) {
    res.status(500).json({ msg: "Failed to fetch cart", error: err.message });
  }
};
